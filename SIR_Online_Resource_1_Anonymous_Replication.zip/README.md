# Reviewer replication bundle

Article: Statutory Paid Annual Leave and National Life Evaluation: A Global Legal-Event Audit and Falsification-First Holdout Study
Journal target: Social Indicators Research
Review status: double-anonymous

Quick reproduction:
  python -m pip install -r requirements.txt
  python code/reproduce_key_results.py

The script retrieves pinned public WHR transport sources, validates expected structure, recomputes the headline eight-event and Israel holdout results, and checks them against the manuscript number lock. Raw third-party datasets are not embedded.
