# Double-anonymous review notice

This archive intentionally omits author names, affiliations, email addresses, ORCID identifiers, funding metadata, competing-interest declarations, institution-specific ethics/exemption metadata, and identifying repository-owner URLs. Author-side declarations are supplied separately through the journal submission system.
