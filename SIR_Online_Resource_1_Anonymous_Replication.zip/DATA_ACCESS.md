# Data access and provenance

Annual Life Ladder data are retrieved at reproduction time from immutable public transport copies of World Happiness Report releases. Raw WHR/Gallup files are not redistributed inside this archive.

World Bank Employing Workers data were used for discovery and contamination screening; only derived registries required for auditing are bundled. Raw Equal Futures data are not redistributed.

A non-anonymized archival location and persistent identifier can be supplied after double-anonymous review.
